# LiquidCrystal_I2C_STEM

LiquidCrystal Arduino library for I2C LCD displays used for STEM schools.

Tested on HD44780 LCD connected to PCF8574 I2C.

Original work by [Frank de Brabander](https://github.com/fdebrabander/Arduino-LiquidCrystal-I2C-library)
